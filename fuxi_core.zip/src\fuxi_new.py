# Copyright 2023 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""The Substructure of FuXiNet"""
import math
import numpy as np

import mindspore as ms
import mindspore.numpy as mnp
import mindspore.common.dtype as mstype
import mindspore.ops.operations as P
from mindspore import nn, ops, Parameter, Tensor, mint
from mindspore.common.initializer import initializer, Uniform


class DropPath(nn.Cell):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """

    def __init__(self, drop_prob, ndim):
        super(DropPath, self).__init__()
        self.drop = nn.Dropout(keep_prob=1 - drop_prob)
        shape = (1,) + (1,) * (ndim + 1)
        self.ndim = ndim
        self.mask = Tensor(np.ones(shape), dtype=mstype.float32)

    def construct(self, x):
        if not self.training:
            return x
        mask = ops.Tile()(self.mask, (x.shape[0],) + (1,) * (self.ndim + 1))
        out = self.drop(mask)
        out = out * x
        return out


def window_partition(x, window_size):
    """
    Args:
        x: (B, H, W, C)
        window_size list[int]: window size, length=2

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    batch_size, h_size, w_size, channel_size = x.shape
    x = x.reshape(batch_size, h_size // window_size[0], window_size[0], w_size // window_size[1], window_size[1], channel_size)
    windows = x.transpose(0, 1, 3, 2, 4, 5).reshape(-1, window_size[0], window_size[1], channel_size)
    return windows


def window_reverse(windows, window_size, h_size, w_size):
    """
    Args:
        windows: (num_windows*B, window_size, window_size, C)
        window_size list[int]: Window size
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, H, W, C)
    """
    batch_size = windows.shape[0]
    batch_size = int(batch_size / (h_size * w_size / window_size[0] / window_size[1]))
    x = windows.reshape(batch_size, h_size // window_size[0], w_size // window_size[1], window_size[0], window_size[1], -1)
    x = x.transpose(0, 1, 3, 2, 4, 5).reshape(batch_size, h_size, w_size, -1)
    return x

class CustomConv3d(nn.Cell):
    """
    Applies a 3D convolution over an input tensor which is typically of shape (N, C, D, H, W)
    """
    def __init__(self, in_channels, out_channels, kernel_size, stride, pad_mode='same',
                 has_bias=False, dtype=ms.float16):
        super(CustomConv3d, self).__init__()
        self.out_channels = out_channels
        self.conv2d_blocks = nn.CellList(
            [nn.Conv2d(in_channels,
                       out_channels,
                       kernel_size=(kernel_size[1], kernel_size[2]),
                       stride=(stride[1], stride[2]),
                       pad_mode=pad_mode,
                       dtype=dtype,
                       ) for _ in range(kernel_size[0])]
        )
        w = Tensor(np.identity(kernel_size[0]), dtype=dtype)
        self.conv2d_weight = ops.expand_dims(ops.expand_dims(w, axis=0), axis=0)
        self.k = kernel_size[0]
        self.stride = stride
        self.pad_mode = pad_mode
        self.conv2d_dtype = dtype
        self.has_bias = has_bias
        if self.has_bias:
            self.bias = Parameter(initializer(Uniform(), [1, out_channels, 1, 1, 1], dtype=dtype))

    def construct(self, x_):
        """
          Process the input tensor through a series of convolutional layers and perform shaping operations.

          Args:
              x: The input tensor with shape (B, C, D, H, W) representing batch size, channels, depth,
              height, and width.

          Returns:
              The output tensor after convolution, reshaping, and optional bias addition, with the final shape
              depending on the input and layer parameters.
          """
        b, c, d, h, w = x_.shape
        x_ = x_.transpose(0, 2, 1, 3, 4).reshape(b * d, c, h, w)
        out = []
        for i in range(self.k):
            out.append(self.conv2d_blocks[i](x_))
        out = ops.stack(out, axis=-1)
        _, cnew, hnew, wnew, _ = out.shape
        out = out.reshape(b, d, cnew, hnew, wnew, self.k).transpose(0, 2, 3, 4, 1, 5).reshape(-1, 1, d, self.k)
        out = ops.conv2d(out, self.conv2d_weight, stride=(self.stride[0], 1), pad_mode='valid')
        out = out.reshape(b, cnew, hnew, wnew, -1).transpose(0, 1, 4, 2, 3)
        if self.has_bias:
            out += self.bias
        return out


class CubeEmbed(nn.Cell):
    """
    Cube Embedding for high dimension data with support for t_in=n.
    """

    def __init__(self, out_channels, h_size, w_size, level_feature_size, pressure_level_num,  batch_size, patch_size):
        super().__init__()
        self.out_channels = out_channels
        # self.patch_size = patch_size
        self.h_size = h_size
        self.w_size = w_size
        self.batch_size = batch_size
        self.level_feature_size = level_feature_size
        self.pressure_level_num = pressure_level_num
        self.conv3d_dtype = mstype.float16
        self.cube3d = CustomConv3d(pressure_level_num * level_feature_size, out_channels, kernel_size=(1, patch_size, patch_size), pad_mode="valid", stride=(1, patch_size, patch_size), has_bias=True, dtype=mstype.float32)
        self.layer_norm = nn.LayerNorm([out_channels], epsilon=1e-5)

    def construct(self, x_input):
        """CubeEmbed forward function with support for t_in=n."""
        x = x_input.reshape(self.batch_size, self.h_size, self.w_size, 1, self.level_feature_size * self.pressure_level_num)
        x = ops.cast(x, self.conv3d_dtype)
        x = x.transpose(0, 4, 3, 1, 2)
        x = self.cube3d(x)
        x = ops.cast(x, x_input.dtype)
        output = self.layer_norm(x.transpose(0, 2, 3, 4, 1))
        return output


class ResidualBlock(nn.Cell):
    """
    Residual Block in down sample.
    """
    def __init__(self,
                 in_channels,
                 out_channels):
        super().__init__()
        self.conv2d_1 = nn.Conv2d(in_channels=in_channels,
                                  out_channels=out_channels,
                                  kernel_size=3,
                                  padding=1,
                                  pad_mode="pad",
                                  stride=1,
                                  has_bias=True)
        self.group_norm = nn.GroupNorm(8, 8)
        self.conv2d_2 = nn.Conv2d(in_channels=in_channels,
                                  out_channels=out_channels,
                                  kernel_size=3,
                                  padding=1,
                                  pad_mode="pad",
                                  stride=1,
                                  has_bias=True)
        self.silu = nn.SiLU()

    def construct(self, x):
        """Residual Block forward function."""
        x1 = x
        x = self.conv2d_1(x)
        x = self.silu(x)
        x = self.conv2d_2(x)
        output = x + x1
        return output


class DownSample(nn.Cell):
    """Down Sample module with support for t_in=n."""
    def __init__(self, in_channels=96, out_channels=192):
        super().__init__()
        self.in_channels = in_channels
        self.conv2d = nn.Conv2d(
                                in_channels=in_channels,
                                # in_channels=in_channels,
                                out_channels=out_channels,
                                kernel_size=(3, 3),
                                stride=2,
                                has_bias=True)
        self.residual_block = ResidualBlock(in_channels=out_channels,
                                            out_channels=out_channels)
        self.silu = nn.SiLU()
        self.in_channels = in_channels
        # self.patch_size = patch_size

    def construct(self, x):
        """Down Sample forward function with support for t_in=n."""
        batch_size, t_new, h_new, w_new, _ = x.shape
        x = x.transpose(0, 1, 4, 2, 3).reshape(batch_size, -1, h_new, w_new)

        # 2D卷积
        x = self.conv2d(x)

        # 残差块
        x = self.residual_block(x)

        # 激活函数
        x = self.silu(x)

        # 调整维度顺序为 (batch_size, patch_size, h_size // 2, w_size // 2, channels * 2)
        output = x.transpose(0, 2, 3, 1)

        return output


class RelativeBias(nn.Cell):
    """RelativeBias for relative position encoding."""
    def __init__(self, type_windows, num_heads, window_size):
        super(RelativeBias, self).__init__()
        self.window_size = window_size

        self.num_heads = num_heads
        self.cpb_mlp = nn.SequentialCell([nn.Dense(2, 512, has_bias=True),
                                     nn.ReLU(),
                                     nn.Dense(512, num_heads, has_bias=False)])
        relative_coords_h = ops.arange(-(self.window_size[0] - 1), self.window_size[0], dtype=ms.float32)
        relative_coords_w = ops.arange(-(self.window_size[1] - 1), self.window_size[1], dtype=ms.float32)
        relative_coords_table = ops.stack(ops.meshgrid(relative_coords_h, relative_coords_w)).transpose(1, 2, 0)
        relative_coords_table = ops.expand_dims(relative_coords_table, axis=0) 
        relative_coords_table[:, :, :, 0] /= (self.window_size[0] - 1)
        relative_coords_table[:, :, :, 1] /= (self.window_size[1] - 1)
        relative_coords_table *= 8  # normalize to -8, 8
        relative_coords_table = ops.sign(relative_coords_table) * ops.log2(ops.abs(relative_coords_table) + 1.0) / 3.0
        self.relative_coords_table = relative_coords_table
        coords_h = ops.arange(self.window_size[0])
        coords_w = ops.arange(self.window_size[1])
        coords = ops.stack(ops.meshgrid(coords_h, coords_w))  # 2, Wh, Ww
        coords_flatten = ops.flatten(coords, start_dim=1)  # 2, Wh*Ww
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
        relative_coords = relative_coords.transpose(1, 2, 0)  # Wh*Ww, Wh*Ww, 2
        relative_coords[:, :, 0] += self.window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
        self.relative_position_index = relative_position_index


    def construct(self):
        """Relative Bias forward function."""
        relative_position_bias_table = self.cpb_mlp(self.relative_coords_table).reshape(-1, self.num_heads)
        relative_position_bias = relative_position_bias_table[self.relative_position_index.reshape(-1)].reshape(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)  # Wh*Ww,Wh*Ww,nH
        relative_position_bias = relative_position_bias.transpose(2, 0, 1)  # nH, Wh*Ww, Wh*Ww
        relative_position_bias = 16 * ops.sigmoid(relative_position_bias)
        relative_position_bias = ops.expand_dims(relative_position_bias, axis=0)
        return relative_position_bias


class WindowAttention(nn.Cell):
    """Window Attention in Swin Block."""
    def __init__(self, dim, num_heads, window_size, input_shape, attn_drop, proj_drop):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.window_size = window_size
        self.logit_scale = Parameter(ops.log(10 * ops.ones((num_heads, 1, 1))), requires_grad=True)
        self.normalize = ops.L2Normalize(axis=-1)
        self.relative_bias = RelativeBias((input_shape[0] // window_size[0]) * (input_shape[1] // window_size[1]),
                                          num_heads, window_size)
        
        self.q = nn.Dense(in_channels=dim, out_channels=dim, has_bias=True)
        self.k = nn.Dense(in_channels=dim, out_channels=dim, has_bias=True)
        self.v = nn.Dense(in_channels=dim, out_channels=dim, has_bias=True)
        self.proj = nn.Dense(dim, dim)
        self.matmul = ops.BatchMatMul()
        # self.attn_drop = nn.Dropout(keep_prob=1. - attn_drop)
        self.proj_drop = nn.Dropout(keep_prob=1. - proj_drop)
    
    def softmax(self, x, axis=-1):
        max_x = x.max(axis=axis, keepdims=True)
        out = ops.exp(x - max_x)
        out_sum = ops.sum(out, dim=axis, keepdim=True) + 1e-16
        return out / out_sum

    def construct(self, x, mask=None):
        """Window Attention in Swin Block."""
        b, window_hw, channels = x.shape
        q = self.q(x).reshape(b, window_hw, self.num_heads,
                              self.dim // self.num_heads).transpose(0, 2, 1, 3)
        k = self.k(x).reshape(b, window_hw, self.num_heads,
                              self.dim // self.num_heads).transpose(0, 2, 1, 3)
        v = self.v(x).reshape(b, window_hw, self.num_heads,
                              self.dim // self.num_heads).transpose(0, 2, 1, 3)
        attn = (self.matmul(self.normalize(q), self.normalize(k).transpose(0, 1, 3, 2)))
        logit_scale = ops.clamp(self.logit_scale, max=ops.log(Tensor(1. / 0.01))).exp()
        attn = attn * logit_scale
        
        attn = attn + self.relative_bias()
        if mask is not None:
            window_nums = mask.shape[0]
            attn = attn.reshape(b // window_nums, window_nums, self.num_heads, window_hw, window_hw) + \
                   ops.expand_dims(ops.expand_dims(mask, axis=1), axis=0)
            attn = attn.reshape(-1, self.num_heads, window_hw, window_hw)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)
        # attn = self.attn_drop(attn)
        attn = P.Cast()(attn, v.dtype)
        x = self.matmul(attn, v).transpose(0, 2, 1, 3).reshape(b, window_hw, channels)
        output = self.proj(x)
        output = self.proj_drop(output)
        return output


class Mlp(nn.Cell):
    """MLP Layer."""

    def __init__(self, in_features, hidden_features=None, out_features=None):
        super(Mlp, self).__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Dense(in_features, hidden_features)
        self.act_layer = nn.GELU(approximate=False)
        self.fc2 = nn.Dense(hidden_features, out_features)

    def construct(self, x):
        """MLP Layer forward function"""
        x = self.fc1(x)
        x = self.act_layer(x)
        x = self.fc2(x)
        return x


class TransformerBlock(nn.Cell):
    """Swin Transformer Block."""

    def __init__(self,
                 shift_size,
                 window_size,
                 dim=192,
                 num_heads=6,
                 h_size=90,
                 w_size=180,
                 input_shape=None,
                 mlp_ratio=4.,
                 drop_path=0.3,
                 attn_drop=0.0,
                 drop=0.2
                 ):
        super().__init__()
        self.dim = dim
        self.shift_size = shift_size
        self.window_size = window_size
        self.h_size = h_size
        self.w_size = w_size
        self.norm1 = nn.LayerNorm([dim], epsilon=1e-5)
        self.attn = WindowAttention(dim,
                                    num_heads=num_heads,
                                    window_size=window_size,
                                    input_shape=input_shape,
                                    attn_drop=attn_drop,
                                    proj_drop=drop
                                    )
        self.norm2 = nn.LayerNorm([dim], epsilon=1e-5)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim)

        if self.shift_size[0] > 0 or self.shift_size[1] > 0:
            h_line = [0, h_size - window_size[0], h_size - shift_size[0], h_size]
            w_line = [0, w_size - window_size[1], w_size - shift_size[1], w_size]
            img_mask = []
            cnt = 0
            for i in range(3):
                tmp = []
                for j in range(3):
                    if h_line[i + 1] > h_line[i] and w_line[j + 1] > w_line[j]:
                        tmp.append(ops.ones((1, h_line[i + 1] - h_line[i], w_line[j + 1] - w_line[j], 1)) * cnt)
                    cnt += 1
                if len(tmp) > 0:
                    img_mask.append(ops.concat(tmp, axis=2))
            img_mask = ops.concat(img_mask, axis=1)
            # windows = x.transpose(0, 1, 3, 2, 4, 5).reshape(-1, window_size[0], window_size[1], 1)
            mask_windows = window_partition(img_mask, self.window_size)
            mask_windows = mask_windows.reshape(-1, self.window_size[0] * self.window_size[1])
            attn_mask = ops.expand_dims(mask_windows, axis=1) - ops.expand_dims(mask_windows, axis=2)
            self.attn_mask = ops.masked_fill(ops.masked_fill(attn_mask, attn_mask != 0, float(-100.0)), attn_mask == 0,
                                    float(0.0))
        else:
            self.attn_mask = None
        self.drop_path = DropPath(drop_path, ndim=1) if drop_path > 0. else nn.Identity()

    def construct(self, x):
        """Swin Transformer Block forward function"""
        batch_size = x.shape[0]
        channel_size = x.shape[2]
        shortcut = x
        x = x.reshape(batch_size, self.h_size, self.w_size, channel_size)

        # cyclic shift
        if self.shift_size[0] > 0 or self.shift_size[1] > 0:
            shifted_x = mnp.roll(x,
                                 shift=(-self.shift_size[0], -self.shift_size[1]),
                                 axis=(1, 2))
        else:
            shifted_x = x
        x_windows = window_partition(shifted_x, self.window_size)
        x_windows = x_windows.reshape(-1, self.window_size[0] * self.window_size[1], channel_size)

        # W-MSA/SW-MSA
        attn_windows = self.attn(x_windows, self.attn_mask)

        # merge windows
        attn_windows = attn_windows.reshape(-1, self.window_size[0], self.window_size[1], channel_size)
        shifted_x = window_reverse(attn_windows, self.window_size, self.h_size, self.w_size)

        # reverse cyclic shift
        if self.shift_size[0] > 0 or self.shift_size[1] > 0:
            x = mnp.roll(shifted_x,
                         shift=(self.shift_size[0], self.shift_size[1]),
                         axis=(1, 2))
        else:
            x = shifted_x
        x = x.reshape(batch_size, self.h_size * self.w_size, channel_size)

        # FFN
        # x = shortcut + self.norm1(x)
        # output = x + self.norm2(self.mlp(x))
        x = shortcut + self.drop_path(self.norm1(x))
        output = x + self.drop_path(self.norm2(self.mlp(x)))
        return output


class BaseBlock(nn.Cell):
    """Base Block."""
    def __init__(self,
                 window_size=(4, 4),
                 shift_size=(3, 3),
                 h_size=90,
                 w_size=180,
                 in_channels=192,
                 input_shape=None,
                 recompute=False):
        super().__init__()
        self.window_size = window_size
        # self.shift_size = shift_size
        self.in_channels = in_channels

        self.blk1 = TransformerBlock(dim=in_channels, h_size=h_size, w_size=w_size, shift_size=[0, 0], window_size=self.window_size, input_shape=input_shape)
        self.blk2 = TransformerBlock(dim=in_channels, h_size=h_size, w_size=w_size, shift_size=[3, 3], window_size=self.window_size, input_shape=input_shape)

        if recompute:
            # self.blk1.recompute()
            # self.blk2.recompute()
            p = 0

    def construct(self, x):
        """Base Block forward function."""
        x = self.blk1(x)
        x = self.blk2(x)
        return x


class UpSample(nn.Cell):
    """Up Sample module."""
    def __init__(self, in_channels=768, out_channels=384, patch_size=4):
        super().__init__()
        self.conv2dtrans = nn.Conv2dTranspose(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=(3, 3),
            stride=2,
            has_bias=True)
        self.residual_block = ResidualBlock(in_channels=out_channels, out_channels=out_channels)
        self.silu = nn.SiLU()
        self.patch_size = patch_size

    def construct(self, x, h_size, w_size):
        """Up Sample forward function."""
        batch_size, channels, _, _ = x.shape
        x1 = x.reshape(batch_size * self.patch_size, channels // self.patch_size, h_size, w_size)
        x2 = self.conv2dtrans(x1)
        x3 = self.residual_block(x2)
        x4 = self.silu(x3)
        x5 = x4.transpose(0, 2, 3, 1)
        output = x5.reshape(batch_size, self.patch_size, h_size * 2, w_size * 2, channels // 2)
        return output


class PatchRecover(nn.Cell):
    """Patch Recover module."""
    def __init__(self,
                 channels,
                 level_feature_size,
                 pressure_level_num,
                 patch_size):
        super().__init__()
        self.channels = channels
        self.patch_size = patch_size
        self.level_feature_size = level_feature_size
        self.pressure_level_num = pressure_level_num
        out_channels = level_feature_size * pressure_level_num * patch_size * patch_size
        self.fc_layer = nn.Dense(channels * patch_size * patch_size, out_channels)

    def construct(self, x):
        """Patch Recover forward function."""
        batch_size, _, h_size, w_size, _ = x.shape
        x = x.transpose(0, 2, 3, 1, 4).reshape(batch_size, h_size, w_size, -1)
        out = self.fc_layer(x)
        out = out.reshape(batch_size, h_size, w_size, -1, self.patch_size, self.patch_size)
        out = out.transpose(0, 3, 1, 4, 2, 5).reshape(batch_size, -1, h_size * self.patch_size, w_size * self.patch_size)
        output = out[:, :self.level_feature_size * self.pressure_level_num]
        output = output.reshape(batch_size, self.level_feature_size, self.pressure_level_num, h_size * self.patch_size, w_size * self.patch_size)
        return output


class FuXiStage1(nn.Cell):
    """
    Stage 1: Upsample 256x256x30 → 512x512x30 (spatial 2×).
    """
    def __init__(
        self,
        depths=6,
        in_channels=96,
        out_channels=192,
        low_h=256,
        low_w=256,
        low_z=30,
        in_feature_size=6,
        kernel_size=(1, 8, 8),
        batch_size=1,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels

        self.cube_embed = CubeEmbed(
            in_channels=in_channels,
            h_size=low_h,
            w_size=low_w,
            level_feature_size=in_feature_size,
            pressure_level_num=low_z,
            batch_size=batch_size,
        )

        self.down_sample = DownSample(in_channels=in_channels, out_channels=out_channels)

        self.swin_blocks = nn.CellList([
            BaseBlock(
                in_channels=out_channels,
                input_shape=[low_z, low_h // 8, low_w // 8],
            ) for _ in range(depths)
        ])

        self.up_sample = UpSample2x(in_channels=out_channels, out_channels=out_channels)
        self.patch_recover = PatchRecover(
            channels=out_channels,
            h_size=low_h * 4,
            w_size=low_w * 4,
            level_feature_size=5,
            pressure_level_num=low_z,
            kernel_size=kernel_size,
        )

    def construct(self, inputs):
        # inputs: (B, low_z, H, W, C)
        # print("Stage 1 inputs shape:", inputs.shape)
        out = self.cube_embed(inputs)  # → (B, C, Z, H, W)
        # print("After CubeEmbed shape:", out.shape)
        out = self.down_sample(out)    # → (B, Z, H//2, W//2, C)
        # print("After DownSample shape:", out.shape)
        B, Z, H, W, _ = out.shape
        out_skip = out.reshape(B, -1, self.out_channels)

        out_swin = out_skip
        for blk in self.swin_blocks:
            out_swin = blk(out_swin, B, Z, H, W)

        # out = ops.concat((out_skip, out_swin), axis=2)
        out = out_skip + out_swin
        out = out.reshape(B, Z, H, W, self.out_channels)
        # print("After Swin Blocks shape:", out.shape)
        out = self.up_sample(out)  # → (B, Z, 2×H, 2×W, C)
        out = self.up_sample(out)  # → (B, C, 4×H, 4×W, Z)
        out = self.patch_recover(out)  # → (B, C, 16×H, 16×W, Z)
        # print("After UpSample shape:", out.shape)
        return out


class ZUpsample(nn.Cell):
    """
    Upsample along the Z (vertical) dimension: 30 → 60
    """
    def __init__(self, in_z=30, out_z=60):
        super().__init__()
        self.linear = nn.Dense(in_channels=in_z, out_channels=out_z)

    def construct(self, x):
        # x: (B, C, Z, H, W)
        B, C, Z, H, W = x.shape
        
        x = x.transpose(1, 3, 4, 0, 2)
        x = x.reshape(C * H * W, B, Z)
        x = self.linear(x)
        x = x.reshape(C, H, W, B, -1).transpose(3, 0, 4, 1, 2)
        return x

    
class CropToTarget(nn.Cell):
    """
    Center crop to target H × W.
    """
    def __init__(self, target_h=785, target_w=625):
        super().__init__()
        self.target_h = target_h
        self.target_w = target_w

    def construct(self, x):
        # x: (B, C, Z, H, W)
        _, _, _, H, W = x.shape
        start_h = (H - self.target_h) // 2
        start_w = (W - self.target_w) // 2
        return x[:, :, :, start_h:start_h + self.target_h, start_w:start_w + self.target_w]
