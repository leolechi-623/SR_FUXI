import mindspore.numpy as mnp
from mindspore import nn, ops

from .fuxi import PatchRecover, CubeEmbed
from .fuxi import BaseBlock, UpSample, DownSample
from .fuxi import FuXiStage1, FuXiStage2, ZUpsample, CropToTarget


class FuXiNet(nn.Cell):
    r"""
    Parameters:
         depths (int): Swin block 数量。
         in_channels (int): 输入通道数。
         out_channels (int): 上采样输出通道数。
         low_h, low_w: 低分辨率 H/W。
         high_h, high_w: 目标高分辨率 H/W。
         level_feature_size (int): level 特征数（用于输出切分）。
         surface_feature_size (int): surface 通道数。
         batch_size (int): 批大小。
         kernel_size (tuple): patch_recover 内核。
    """
    def __init__(
        self,
        depths=18,
        in_channels=96,
        out_channels=192,
        low_h=256,
        low_w=256,
        low_z=30,
        high_h=1024,
        high_w=1024,
        high_z=60,
        out_h=785,
        out_w=625,
        in_feature_size=6,
        out_feature_size=5,
        batch_size=1,
        kernel_size=(2,4,4), 
        **kwargs
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.in_feature_size = in_feature_size
        self.batch_size = batch_size
        # 输入特征展平后已包含所有通道信息，直接分配给 skip
        # Swin Blocks
        # 假设输入分块后形状为 (batch, patches, channels, low_h, low_w)
        self.cube_embed = CubeEmbed(
            in_channels=in_channels,
            h_size=low_h,
            w_size=low_w,
            level_feature_size=in_feature_size,
            pressure_level_num=low_z,
            batch_size=batch_size,
        )
        self.down_sample = DownSample(in_channels=in_channels, out_channels=out_channels)
        self.swin_blocks = nn.CellList([
            BaseBlock(
                in_channels=out_channels,
                input_shape=[low_z, low_h//8, low_w//8],
            ) for _ in range(depths)
        ])
        # 上采样部分
        self.up_sample = UpSample(
            in_channels=out_channels*2,
            out_channels=out_channels
        )
        # Patch 恢复到高分辨率
        self.patch_recover = PatchRecover(
            out_channels,
            low_h*kernel_size[1],
            low_w*kernel_size[2],
            out_feature_size,
            low_z*kernel_size[0],
            kernel_size
        )
        self.interpolate = ops.ResizeBilinearV2()
        self.out_size = (out_h, out_w)

    def construct(self, inputs):
        # inputs: Tensor, shape (batch, channels, low_h, low_w)
        # 1. 先进行一次线性映射（可视为 identity）
        print("Input shape:", inputs.shape)
        out = self.cube_embed(inputs)  # 假设 inputs 已为 (b, z, h, w, C) 格式
        print("After CubeEmbed shape:", out.shape)
        out_down_sample = self.down_sample(out)  # (b, z, h, w, C)
        print("After DownSample shape:", out_down_sample.shape)
        B, Z, H, W, _ = out_down_sample.shape
        out_skip = out_down_sample.reshape(B, -1, self.out_channels)
        out_swin_block = out_skip
        # 2. Swin Block 处理
        for swin_block in self.swin_blocks:
            out_swin_block = swin_block(out_swin_block, B, Z, H, W)
        out_swin_block = ops.concat((out_skip, out_swin_block), axis=2)
        # 3. concat skip
        out_swin_block = out_swin_block.reshape(B, Z, H, W, self.out_channels * 2)
        print("After Swin Blocks shape:", out_swin_block.shape)
        out_up_sample = self.up_sample(out_swin_block)
        print("After UpSample shape:", out_up_sample.shape)
        output = self.patch_recover(out_up_sample)
        print("After PatchRecover shape:", output.shape)
        B, C, Z, H, W = output.shape
        output = output.reshape(B, C * Z, H, W)
        output = self.interpolate(output, self.out_size)
        output = output.reshape(B, C, Z, self.out_size[0], self.out_size[1])
        return output


class FuXiNetSplit(nn.Cell):
    """
    Full pipeline: 256×256×30 → 512×512×30 → 1024×1024×30 → 1024×1024×60 → 785×625×60
    """
    def __init__(self, config):
        super().__init__()
        self.stage1 = FuXiStage1(
            depths=config['stage1_depth'],
            in_channels=config['in_channels'],
            out_channels=config['mid_channels'],
            low_h=256,
            low_w=256,
            low_z=30,
            in_feature_size=config['in_feature_size'],
            kernel_size=config['kernel_size'],
            batch_size=config['batch_size']
        )
        # self.stage2 = FuXiStage2(
        #     depths=config['stage2_depth'],
        #     in_channels=config['mid_channels'],
        #     out_channels=config['out_channels'],
        #     low_h=512,
        #     low_w=512,
        #     low_z=30,
        #     kernel_size=config['kernel_size'],
        #     batch_size=config['batch_size']
        # )
        self.z_upsample = ZUpsample(in_z=30, out_z=60)
        self.crop = CropToTarget(target_h=785, target_w=625)
        self.post_smoother = nn.SequentialCell([
            nn.Conv3d(
                in_channels=5, out_channels=5, kernel_size=3, stride=1, has_bias=True
            ),
            nn.ReLU(),
            nn.Conv3d(
                in_channels=5, out_channels=5, kernel_size=3, stride=1, has_bias=True
            )
        ])

    def construct(self, x):
        # x: (B, Z=30, H=256, W=256, C=6)
        x = self.stage1(x)  # → 512×512×30
        # x = self.stage2(x)  # → 1024×1024×30
        # x = x.transpose(0, 4, 1, 2, 3)  # (B, C, Z, H, W)
        x = self.z_upsample(x)         # → (B, C, 60, 1024, 1024)
        x = self.crop(x)               # → (B, C, 60, 785, 625)
        # x = self.post_smoother(x)
        return x
