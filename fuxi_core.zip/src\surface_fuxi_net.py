import mindspore.numpy as mnp
from mindspore import nn, ops
from .surface_fuxi import PatchRecover, CubeEmbed
from .surface_fuxi import BaseBlock, UpSamplePS, DownSample


class FuXiNet(nn.Cell):
    r"""
    简化的 FuXiNet，用于海洋超分，移除 CubeEmbed，直接处理传入的特征。

    Parameters:
         depths (int): Swin block 数量。
         in_channels (int): 输入通道数。
         out_channels (int): 上采样输出通道数。
         low_h, low_w: 低分辨率 H/W。
         high_h, high_w: 目标高分辨率 H/W。
         level_feature_size (int): level 特征数（用于输出切分）。
         surface_feature_size (int): surface 通道数。
         batch_size (int): 批大小。
         kernel_size (tuple): patch_recover 内核。
    """
    def __init__(
        self,
        depths=6,
        in_channels=96,
        out_channels=192,
        low_h=256,
        low_w=256,
        low_z=1,
        high_h=1024,
        high_w=1024,
        high_z=1,
        out_h=785,
        out_w=625,
        in_feature_size=5,
        out_feature_size=1,
        batch_size=1,
        kernel_size=(1,4,4), 
        **kwargs
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.in_feature_size = in_feature_size
        self.batch_size = batch_size

        # CubeEmbed: 将输入展开到 (B, Z, H, W, C)
        self.cube_embed = CubeEmbed(
            in_channels=in_channels,
            h_size=low_h,
            w_size=low_w,
            level_feature_size=in_feature_size,
            pressure_level_num=low_z,
            batch_size=batch_size,
        )
        # 下采样
        self.down_sample = DownSample(
            in_channels=in_channels,
            out_channels=out_channels
        )

        # Swin Transformer Blocks
        # 计算下采样后空间尺寸
        sh, sw = low_h // 8, low_w // 8
        # 设置 window_size，深度方向为 1，空间方向为整个下采样特征图
        ws = (1, sh, sw)
        self.swin_blocks = nn.CellList([
            BaseBlock(
                in_channels=out_channels,
                input_shape=[low_z, sh, sw],
                window_size=ws,
                recompute=True
            ) for _ in range(depths)
        ])

        # 上采样部分
        self.up_sample = UpSamplePS(
            in_channels=out_channels * 2,
            out_channels=out_channels
        )
      
        # PatchRecover: 恢复到高分辨率网格
        self.patch_recover = PatchRecover(
            out_channels,
            low_h * kernel_size[1],
            low_w * kernel_size[2],
            out_feature_size,
            low_z * kernel_size[0],
            kernel_size
        )
        self.interpolate = ops.ResizeBilinearV2()
        self.out_size = (out_h, out_w)

    def construct(self, inputs):
        # inputs: (B, C, H, W)
        # 1. 将输入转换为 (B, Z, H, W, C)
        out = self.cube_embed(inputs)
        # 2. 下采样
        out_ds = self.down_sample(out)
        B, Z, H, W, C = out_ds.shape
        # 3. Swin 处理前 reshape
        out_skip = out_ds.reshape(B, -1, C)
        x = out_skip
        # 4. 逐层 Swin Block
        for block in self.swin_blocks:
            x = block(x, B, Z, H, W)
        # 5. 跳跃连接
        if x.dtype != out_skip.dtype:
            x = ops.cast(x, out_skip.dtype)
        x = ops.concat((out_skip, x), axis=2)
        x = x.reshape(B, Z, H, W, C * 2)
        # 6. 上采样
        out_us = self.up_sample(x)
        # 7. Patch 恢复到高分辨率
        out_pr = self.patch_recover(out_us)
        B2, C2, Z2, H2, W2 = out_pr.shape
        # 8. reshape 并插值
        out_r = out_pr.reshape(B2, C2 * Z2, H2, W2)
        out_interp = self.interpolate(out_r, self.out_size)
        # 9. reshape 回 (B, C, Z, out_h, out_w)
        out_final = out_interp.reshape(B2, C2, Z2, self.out_size[0], self.out_size[1])
        return out_final
